﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_System
{
    public partial class LibrarySystem : Form
    {
        Image groundmap;

        public LibrarySystem()
        {
            InitializeComponent();

        }

        private void GroundFloorTab_Click(object sender, EventArgs e)
        {

        }

        private void GroundFloorpanel_Paint(object sender, PaintEventArgs e)
        {
            GroundFloorpanel.AutoScroll = true;
            gmapbox.SizeMode = PictureBoxSizeMode.AutoSize;
        }

        private void Grid_Click(object sender, EventArgs e)
        {






        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {


        }

        private void genmap_Click(object sender, EventArgs e)
        {
            
        }

        Image Zoom(Image img, Size size)
        {
            Bitmap bmp = new Bitmap(img, img.Width + (img.Width * size.Width / 100), img.Height + (img.Height * size.Height / 100));
            Graphics gen = Graphics.FromImage(bmp);
            gen.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            return bmp;
                        
        }
        
        private void Zoombar_Scroll(object sender, EventArgs e)
        {

            gmapbox.Image = Zoom(groundmap, new Size(Zoombar.Value, Zoombar.Value));
        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        

        private void Grid_Click_1(object sender, EventArgs e)
        {
            int xbox = Convert.ToInt32(this.XBox.Text);
            int ybox = Convert.ToInt32(this.YBox.Text);
            int ButtonWidth = 10;
            int ButtonHeight = 10;
            int Distance = 20;
            int start_x = 60;
            int start_y = 60;
            int buttonx = start_x + (xbox * ButtonHeight + Distance);
            int buttony = start_y + (ybox * ButtonWidth + Distance);
                        
                    Button up = new Button();
                    up.Width = 10;
                    up.Height = 200;
                    up.Top = buttonx - 95;
                    up.Left = buttony;
                    up.FlatStyle = FlatStyle.Flat;
                    up.FlatAppearance.BorderSize = 0;
                    up.ForeColor = Color.Blue;
                    up.BackColor = Color.Blue;
                    this.Controls.Add(up);
                    up.BringToFront();

                    Button right = new Button();
                    right.Width = 200;
                    right.Height = 10;
                    right.Top = buttonx;
                    right.Left = buttony - 95;
                    right.FlatStyle = FlatStyle.Flat;
                    right.FlatAppearance.BorderSize = 0;
                    right.ForeColor = Color.Green;
                    right.BackColor = Color.Green;
                    this.Controls.Add(right);
                    right.BringToFront();

                    Button point = new Button();
                    point.Top = buttonx;
                    point.Left = buttony;
                    point.Width = ButtonWidth;
                    point.Height = ButtonHeight;
                    point.FlatStyle = FlatStyle.Flat;
                    point.FlatAppearance.BorderSize = 0;
                    point.ForeColor = Color.Red;
                    point.BackColor = Color.Red;
                    this.Controls.Add(point);
                    point.BringToFront();  
        }

        private void genemap_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Multiselect = false, ValidateNames = true, Filter = "JPEG|*.jpg" })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    gmapbox.Image = Image.FromFile(ofd.FileName);
                    groundmap = gmapbox.Image;
                }
            }
        }

        private void XBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
