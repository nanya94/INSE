﻿namespace Library_System
{
    partial class LibrarySystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SeatingTab = new System.Windows.Forms.TabControl();
            this.SeatBookingTab = new System.Windows.Forms.TabPage();
            this.seattab = new System.Windows.Forms.TabControl();
            this.bookseat = new System.Windows.Forms.TabPage();
            this.bookbutton = new System.Windows.Forms.Button();
            this.LengthBox = new System.Windows.Forms.MaskedTextBox();
            this.StartTimeBox = new System.Windows.Forms.MaskedTextBox();
            this.DateBox = new System.Windows.Forms.DateTimePicker();
            this.FloorBox = new System.Windows.Forms.ComboBox();
            this.SeatTypeBox = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.seatgroup = new System.Windows.Forms.TabPage();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.timeinfo = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.BookBookingTab = new System.Windows.Forms.TabPage();
            this.label52 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.maskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox11 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox12 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox13 = new System.Windows.Forms.MaskedTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.MapsTab = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Zoombar = new System.Windows.Forms.TrackBar();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.XBox = new System.Windows.Forms.TextBox();
            this.YBox = new System.Windows.Forms.TextBox();
            this.XBox2 = new System.Windows.Forms.TextBox();
            this.YBox2 = new System.Windows.Forms.TextBox();
            this.XBox3 = new System.Windows.Forms.TextBox();
            this.YBox3 = new System.Windows.Forms.TextBox();
            this.gmappointbox = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.GroundFloorTab = new System.Windows.Forms.TabPage();
            this.GroundFloorpanel = new System.Windows.Forms.Panel();
            this.gmapbox = new System.Windows.Forms.PictureBox();
            this.FirstFloorTab = new System.Windows.Forms.TabPage();
            this.FirstFloorpanel = new System.Windows.Forms.Panel();
            this.mappointbox2 = new System.Windows.Forms.PictureBox();
            this.mapbox2 = new System.Windows.Forms.PictureBox();
            this.SecondFloorTab = new System.Windows.Forms.TabPage();
            this.SecondFloorpanel = new System.Windows.Forms.Panel();
            this.mappointbox3 = new System.Windows.Forms.PictureBox();
            this.mapbox3 = new System.Windows.Forms.PictureBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.seatingDataSet1 = new Library_System.SeatingDataSet();
            this.seatingDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SeatingTab.SuspendLayout();
            this.SeatBookingTab.SuspendLayout();
            this.seattab.SuspendLayout();
            this.bookseat.SuspendLayout();
            this.seatgroup.SuspendLayout();
            this.timeinfo.SuspendLayout();
            this.BookBookingTab.SuspendLayout();
            this.MapsTab.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Zoombar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gmappointbox)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.GroundFloorTab.SuspendLayout();
            this.GroundFloorpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gmapbox)).BeginInit();
            this.FirstFloorTab.SuspendLayout();
            this.FirstFloorpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mappointbox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mapbox2)).BeginInit();
            this.SecondFloorTab.SuspendLayout();
            this.SecondFloorpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mappointbox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mapbox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatingDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatingDataSet1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SeatingTab
            // 
            this.SeatingTab.Controls.Add(this.SeatBookingTab);
            this.SeatingTab.Controls.Add(this.BookBookingTab);
            this.SeatingTab.Controls.Add(this.MapsTab);
            this.SeatingTab.Location = new System.Drawing.Point(68, 1);
            this.SeatingTab.Name = "SeatingTab";
            this.SeatingTab.SelectedIndex = 0;
            this.SeatingTab.Size = new System.Drawing.Size(1286, 720);
            this.SeatingTab.TabIndex = 0;
            // 
            // SeatBookingTab
            // 
            this.SeatBookingTab.Controls.Add(this.seattab);
            this.SeatBookingTab.Location = new System.Drawing.Point(4, 22);
            this.SeatBookingTab.Name = "SeatBookingTab";
            this.SeatBookingTab.Padding = new System.Windows.Forms.Padding(3);
            this.SeatBookingTab.Size = new System.Drawing.Size(1278, 694);
            this.SeatBookingTab.TabIndex = 0;
            this.SeatBookingTab.Text = "Seat Booking";
            this.SeatBookingTab.UseVisualStyleBackColor = true;
            // 
            // seattab
            // 
            this.seattab.Controls.Add(this.bookseat);
            this.seattab.Controls.Add(this.seatgroup);
            this.seattab.Controls.Add(this.timeinfo);
            this.seattab.Location = new System.Drawing.Point(4, 4);
            this.seattab.Name = "seattab";
            this.seattab.SelectedIndex = 0;
            this.seattab.Size = new System.Drawing.Size(1271, 687);
            this.seattab.TabIndex = 0;
            // 
            // bookseat
            // 
            this.bookseat.Controls.Add(this.bookbutton);
            this.bookseat.Controls.Add(this.LengthBox);
            this.bookseat.Controls.Add(this.StartTimeBox);
            this.bookseat.Controls.Add(this.DateBox);
            this.bookseat.Controls.Add(this.FloorBox);
            this.bookseat.Controls.Add(this.SeatTypeBox);
            this.bookseat.Controls.Add(this.textBox1);
            this.bookseat.Controls.Add(this.label5);
            this.bookseat.Controls.Add(this.label6);
            this.bookseat.Controls.Add(this.label8);
            this.bookseat.Controls.Add(this.label4);
            this.bookseat.Controls.Add(this.label2);
            this.bookseat.Controls.Add(this.label1);
            this.bookseat.Location = new System.Drawing.Point(4, 22);
            this.bookseat.Name = "bookseat";
            this.bookseat.Padding = new System.Windows.Forms.Padding(3);
            this.bookseat.Size = new System.Drawing.Size(1263, 661);
            this.bookseat.TabIndex = 0;
            this.bookseat.Text = "Book Seat";
            this.bookseat.UseVisualStyleBackColor = true;
            // 
            // bookbutton
            // 
            this.bookbutton.Location = new System.Drawing.Point(211, 252);
            this.bookbutton.Name = "bookbutton";
            this.bookbutton.Size = new System.Drawing.Size(75, 23);
            this.bookbutton.TabIndex = 42;
            this.bookbutton.Text = "Book!";
            this.bookbutton.UseVisualStyleBackColor = true;
            this.bookbutton.Click += new System.EventHandler(this.bookbutton_Click);
            // 
            // LengthBox
            // 
            this.LengthBox.Location = new System.Drawing.Point(211, 207);
            this.LengthBox.Mask = "00000";
            this.LengthBox.Name = "LengthBox";
            this.LengthBox.Size = new System.Drawing.Size(35, 20);
            this.LengthBox.TabIndex = 23;
            this.LengthBox.ValidatingType = typeof(int);
            // 
            // StartTimeBox
            // 
            this.StartTimeBox.Location = new System.Drawing.Point(211, 181);
            this.StartTimeBox.Mask = "00:00";
            this.StartTimeBox.Name = "StartTimeBox";
            this.StartTimeBox.Size = new System.Drawing.Size(35, 20);
            this.StartTimeBox.TabIndex = 22;
            this.StartTimeBox.ValidatingType = typeof(System.DateTime);
            // 
            // DateBox
            // 
            this.DateBox.Location = new System.Drawing.Point(211, 155);
            this.DateBox.Name = "DateBox";
            this.DateBox.Size = new System.Drawing.Size(130, 20);
            this.DateBox.TabIndex = 20;
            this.DateBox.Value = new System.DateTime(2017, 4, 28, 0, 0, 0, 0);
            // 
            // FloorBox
            // 
            this.FloorBox.FormattingEnabled = true;
            this.FloorBox.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.FloorBox.Location = new System.Drawing.Point(211, 128);
            this.FloorBox.Name = "FloorBox";
            this.FloorBox.Size = new System.Drawing.Size(130, 21);
            this.FloorBox.TabIndex = 18;
            this.FloorBox.Text = "0";
            // 
            // SeatTypeBox
            // 
            this.SeatTypeBox.FormattingEnabled = true;
            this.SeatTypeBox.Items.AddRange(new object[] {
            "Desktop",
            "Standard Table",
            "Sofa",
            "Other"});
            this.SeatTypeBox.Location = new System.Drawing.Point(211, 101);
            this.SeatTypeBox.Name = "SeatTypeBox";
            this.SeatTypeBox.Size = new System.Drawing.Size(130, 21);
            this.SeatTypeBox.TabIndex = 17;
            this.SeatTypeBox.Text = "Desktop";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(211, 74);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(48, 20);
            this.textBox1.TabIndex = 16;
            this.textBox1.Text = "--- / 400";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Length of Time? (in mins)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Time Start?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 155);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Date Start?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Floor Preference?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Seat Type?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Number of Seats Available:";
            // 
            // seatgroup
            // 
            this.seatgroup.Controls.Add(this.textBox23);
            this.seatgroup.Controls.Add(this.label48);
            this.seatgroup.Controls.Add(this.textBox24);
            this.seatgroup.Controls.Add(this.label49);
            this.seatgroup.Controls.Add(this.textBox25);
            this.seatgroup.Controls.Add(this.label50);
            this.seatgroup.Controls.Add(this.textBox26);
            this.seatgroup.Controls.Add(this.label51);
            this.seatgroup.Controls.Add(this.textBox15);
            this.seatgroup.Controls.Add(this.label40);
            this.seatgroup.Controls.Add(this.textBox16);
            this.seatgroup.Controls.Add(this.label41);
            this.seatgroup.Controls.Add(this.textBox17);
            this.seatgroup.Controls.Add(this.label42);
            this.seatgroup.Controls.Add(this.textBox18);
            this.seatgroup.Controls.Add(this.label43);
            this.seatgroup.Controls.Add(this.textBox19);
            this.seatgroup.Controls.Add(this.label44);
            this.seatgroup.Controls.Add(this.textBox20);
            this.seatgroup.Controls.Add(this.label45);
            this.seatgroup.Controls.Add(this.textBox21);
            this.seatgroup.Controls.Add(this.label46);
            this.seatgroup.Controls.Add(this.textBox22);
            this.seatgroup.Controls.Add(this.label47);
            this.seatgroup.Controls.Add(this.textBox11);
            this.seatgroup.Controls.Add(this.label36);
            this.seatgroup.Controls.Add(this.textBox12);
            this.seatgroup.Controls.Add(this.label37);
            this.seatgroup.Controls.Add(this.textBox13);
            this.seatgroup.Controls.Add(this.label38);
            this.seatgroup.Controls.Add(this.textBox14);
            this.seatgroup.Controls.Add(this.label39);
            this.seatgroup.Controls.Add(this.textBox9);
            this.seatgroup.Controls.Add(this.label34);
            this.seatgroup.Controls.Add(this.textBox10);
            this.seatgroup.Controls.Add(this.label35);
            this.seatgroup.Controls.Add(this.textBox8);
            this.seatgroup.Controls.Add(this.label33);
            this.seatgroup.Controls.Add(this.textBox7);
            this.seatgroup.Controls.Add(this.label32);
            this.seatgroup.Controls.Add(this.button3);
            this.seatgroup.Controls.Add(this.maskedTextBox3);
            this.seatgroup.Controls.Add(this.maskedTextBox4);
            this.seatgroup.Controls.Add(this.dateTimePicker3);
            this.seatgroup.Controls.Add(this.dateTimePicker4);
            this.seatgroup.Controls.Add(this.comboBox4);
            this.seatgroup.Controls.Add(this.comboBox6);
            this.seatgroup.Controls.Add(this.textBox2);
            this.seatgroup.Controls.Add(this.label9);
            this.seatgroup.Controls.Add(this.label10);
            this.seatgroup.Controls.Add(this.label11);
            this.seatgroup.Controls.Add(this.label12);
            this.seatgroup.Controls.Add(this.label13);
            this.seatgroup.Controls.Add(this.label15);
            this.seatgroup.Controls.Add(this.label16);
            this.seatgroup.Location = new System.Drawing.Point(4, 22);
            this.seatgroup.Name = "seatgroup";
            this.seatgroup.Padding = new System.Windows.Forms.Padding(3);
            this.seatgroup.Size = new System.Drawing.Size(1263, 661);
            this.seatgroup.TabIndex = 1;
            this.seatgroup.Text = "Book Group of Seats";
            this.seatgroup.UseVisualStyleBackColor = true;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(724, 306);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(80, 20);
            this.textBox23.TabIndex = 82;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(648, 309);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(61, 13);
            this.label48.TabIndex = 81;
            this.label48.Text = "Username?";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(724, 280);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(80, 20);
            this.textBox24.TabIndex = 80;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(648, 283);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(61, 13);
            this.label49.TabIndex = 79;
            this.label49.Text = "Username?";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(549, 306);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(80, 20);
            this.textBox25.TabIndex = 78;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(473, 309);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(61, 13);
            this.label50.TabIndex = 77;
            this.label50.Text = "Username?";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(549, 280);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(80, 20);
            this.textBox26.TabIndex = 76;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(473, 283);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(61, 13);
            this.label51.TabIndex = 75;
            this.label51.Text = "Username?";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(724, 254);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(80, 20);
            this.textBox15.TabIndex = 74;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(648, 257);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(61, 13);
            this.label40.TabIndex = 73;
            this.label40.Text = "Username?";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(724, 228);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(80, 20);
            this.textBox16.TabIndex = 72;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(648, 231);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(61, 13);
            this.label41.TabIndex = 71;
            this.label41.Text = "Username?";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(724, 202);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(80, 20);
            this.textBox17.TabIndex = 70;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(648, 205);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(61, 13);
            this.label42.TabIndex = 69;
            this.label42.Text = "Username?";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(724, 176);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(80, 20);
            this.textBox18.TabIndex = 68;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(648, 179);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 13);
            this.label43.TabIndex = 67;
            this.label43.Text = "Username?";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(724, 150);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(80, 20);
            this.textBox19.TabIndex = 66;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(648, 153);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(61, 13);
            this.label44.TabIndex = 65;
            this.label44.Text = "Username?";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(724, 124);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(80, 20);
            this.textBox20.TabIndex = 64;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(648, 127);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(61, 13);
            this.label45.TabIndex = 63;
            this.label45.Text = "Username?";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(724, 98);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(80, 20);
            this.textBox21.TabIndex = 62;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(648, 101);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(61, 13);
            this.label46.TabIndex = 61;
            this.label46.Text = "Username?";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(724, 72);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(80, 20);
            this.textBox22.TabIndex = 60;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(648, 75);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(61, 13);
            this.label47.TabIndex = 59;
            this.label47.Text = "Username?";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(549, 254);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(80, 20);
            this.textBox11.TabIndex = 58;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(473, 257);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(61, 13);
            this.label36.TabIndex = 57;
            this.label36.Text = "Username?";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(549, 228);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(80, 20);
            this.textBox12.TabIndex = 56;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(473, 231);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(61, 13);
            this.label37.TabIndex = 55;
            this.label37.Text = "Username?";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(549, 202);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(80, 20);
            this.textBox13.TabIndex = 54;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(473, 205);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 13);
            this.label38.TabIndex = 53;
            this.label38.Text = "Username?";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(549, 176);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(80, 20);
            this.textBox14.TabIndex = 52;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(473, 179);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(61, 13);
            this.label39.TabIndex = 51;
            this.label39.Text = "Username?";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(549, 150);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(80, 20);
            this.textBox9.TabIndex = 50;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(473, 153);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(61, 13);
            this.label34.TabIndex = 49;
            this.label34.Text = "Username?";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(549, 124);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(80, 20);
            this.textBox10.TabIndex = 48;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(473, 127);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 13);
            this.label35.TabIndex = 47;
            this.label35.Text = "Username?";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(549, 98);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(80, 20);
            this.textBox8.TabIndex = 46;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(473, 101);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(61, 13);
            this.label33.TabIndex = 45;
            this.label33.Text = "Username?";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(549, 72);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(80, 20);
            this.textBox7.TabIndex = 44;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(473, 75);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(61, 13);
            this.label32.TabIndex = 43;
            this.label32.Text = "Username?";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(158, 261);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 42;
            this.button3.Text = "Book!";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(158, 235);
            this.maskedTextBox3.Mask = "90:00";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox3.TabIndex = 31;
            this.maskedTextBox3.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Location = new System.Drawing.Point(158, 209);
            this.maskedTextBox4.Mask = "00:00";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox4.TabIndex = 30;
            this.maskedTextBox4.ValidatingType = typeof(System.DateTime);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(158, 184);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(180, 20);
            this.dateTimePicker3.TabIndex = 29;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(158, 158);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(180, 20);
            this.dateTimePicker4.TabIndex = 28;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6 (Maximum for Small Booth Seating)",
            "7",
            "8",
            "9",
            "10 (Maximum for Large Booth Seating)",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20 (Maximum for Room Seating)"});
            this.comboBox4.Location = new System.Drawing.Point(158, 131);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(180, 21);
            this.comboBox4.TabIndex = 27;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "Any",
            "Desktop Computer",
            "Standard Table",
            "Sofa",
            "Other (Disablity Seats)"});
            this.comboBox6.Location = new System.Drawing.Point(158, 101);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(180, 21);
            this.comboBox6.TabIndex = 25;
            this.comboBox6.Text = "Any";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(158, 75);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(48, 20);
            this.textBox2.TabIndex = 24;
            this.textBox2.Text = "--- / 400";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 232);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Time End?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 207);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Time Start?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 181);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Date End?";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 156);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Date Start?";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 131);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "Number of Seats Needed?";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 109);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Seat Type?";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(135, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "Number of Seats Available:";
            // 
            // timeinfo
            // 
            this.timeinfo.Controls.Add(this.button2);
            this.timeinfo.Controls.Add(this.button1);
            this.timeinfo.Controls.Add(this.textBox4);
            this.timeinfo.Controls.Add(this.dateTimePicker5);
            this.timeinfo.Controls.Add(this.textBox3);
            this.timeinfo.Controls.Add(this.maskedTextBox9);
            this.timeinfo.Controls.Add(this.maskedTextBox7);
            this.timeinfo.Controls.Add(this.maskedTextBox8);
            this.timeinfo.Controls.Add(this.maskedTextBox5);
            this.timeinfo.Controls.Add(this.maskedTextBox6);
            this.timeinfo.Controls.Add(this.label25);
            this.timeinfo.Controls.Add(this.label24);
            this.timeinfo.Controls.Add(this.label14);
            this.timeinfo.Controls.Add(this.label17);
            this.timeinfo.Controls.Add(this.label18);
            this.timeinfo.Controls.Add(this.label19);
            this.timeinfo.Controls.Add(this.label20);
            this.timeinfo.Controls.Add(this.label21);
            this.timeinfo.Controls.Add(this.label22);
            this.timeinfo.Controls.Add(this.label23);
            this.timeinfo.Location = new System.Drawing.Point(4, 22);
            this.timeinfo.Name = "timeinfo";
            this.timeinfo.Size = new System.Drawing.Size(1263, 661);
            this.timeinfo.TabIndex = 2;
            this.timeinfo.Text = "Booked Seat Information";
            this.timeinfo.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(251, 165);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 42;
            this.button2.Text = "Book!";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(146, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 20);
            this.button1.TabIndex = 40;
            this.button1.Text = "Yes";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(146, 88);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(75, 20);
            this.textBox4.TabIndex = 39;
            this.textBox4.Text = "dd:hh:mm:ss";
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Location = new System.Drawing.Point(146, 137);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(180, 20);
            this.dateTimePicker5.TabIndex = 38;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(146, 61);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(48, 20);
            this.textBox3.TabIndex = 37;
            this.textBox3.Text = "--- / 400";
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.Location = new System.Drawing.Point(146, 165);
            this.maskedTextBox9.Mask = "00:00";
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox9.TabIndex = 36;
            this.maskedTextBox9.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox7
            // 
            this.maskedTextBox7.Location = new System.Drawing.Point(146, 268);
            this.maskedTextBox7.Mask = "90:00";
            this.maskedTextBox7.Name = "maskedTextBox7";
            this.maskedTextBox7.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox7.TabIndex = 35;
            this.maskedTextBox7.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.Location = new System.Drawing.Point(146, 242);
            this.maskedTextBox8.Mask = "00:00";
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox8.TabIndex = 34;
            this.maskedTextBox8.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.Location = new System.Drawing.Point(146, 217);
            this.maskedTextBox5.Mask = "90:00";
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox5.TabIndex = 33;
            this.maskedTextBox5.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.Location = new System.Drawing.Point(146, 191);
            this.maskedTextBox6.Mask = "00:00";
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox6.TabIndex = 32;
            this.maskedTextBox6.ValidatingType = typeof(System.DateTime);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 291);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 13);
            this.label25.TabIndex = 25;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 167);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 13);
            this.label24.TabIndex = 24;
            this.label24.Text = "New Time End?";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 267);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "Time End:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 242);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "Time Start:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 216);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "Date End:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 191);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "Date Start:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 144);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 13);
            this.label20.TabIndex = 19;
            this.label20.Text = "New Date End?";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 119);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 13);
            this.label21.TabIndex = 18;
            this.label21.Text = "Add Time?";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 93);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 13);
            this.label22.TabIndex = 17;
            this.label22.Text = "Time Left:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 68);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(135, 13);
            this.label23.TabIndex = 16;
            this.label23.Text = "Number of Seats Available:";
            // 
            // BookBookingTab
            // 
            this.BookBookingTab.Controls.Add(this.label52);
            this.BookBookingTab.Controls.Add(this.button5);
            this.BookBookingTab.Controls.Add(this.textBox6);
            this.BookBookingTab.Controls.Add(this.textBox5);
            this.BookBookingTab.Controls.Add(this.maskedTextBox10);
            this.BookBookingTab.Controls.Add(this.maskedTextBox11);
            this.BookBookingTab.Controls.Add(this.maskedTextBox12);
            this.BookBookingTab.Controls.Add(this.maskedTextBox13);
            this.BookBookingTab.Controls.Add(this.label30);
            this.BookBookingTab.Controls.Add(this.label26);
            this.BookBookingTab.Controls.Add(this.label27);
            this.BookBookingTab.Controls.Add(this.label28);
            this.BookBookingTab.Controls.Add(this.label29);
            this.BookBookingTab.Controls.Add(this.label31);
            this.BookBookingTab.Location = new System.Drawing.Point(4, 22);
            this.BookBookingTab.Name = "BookBookingTab";
            this.BookBookingTab.Padding = new System.Windows.Forms.Padding(3);
            this.BookBookingTab.Size = new System.Drawing.Size(1278, 694);
            this.BookBookingTab.TabIndex = 1;
            this.BookBookingTab.Text = "Book Reserving";
            this.BookBookingTab.UseVisualStyleBackColor = true;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.Red;
            this.label52.Location = new System.Drawing.Point(15, 109);
            this.label52.MaximumSize = new System.Drawing.Size(1000, 300);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(935, 135);
            this.label52.TabIndex = 44;
            this.label52.Text = "COMING SOON";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(101, 213);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 43;
            this.button5.Text = "Reserve!";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(101, 86);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(243, 20);
            this.textBox6.TabIndex = 42;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(101, 261);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(75, 20);
            this.textBox5.TabIndex = 41;
            this.textBox5.Text = "dd:hh:mm:ss";
            // 
            // maskedTextBox10
            // 
            this.maskedTextBox10.Location = new System.Drawing.Point(101, 187);
            this.maskedTextBox10.Mask = "90:00";
            this.maskedTextBox10.Name = "maskedTextBox10";
            this.maskedTextBox10.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox10.TabIndex = 39;
            this.maskedTextBox10.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox11
            // 
            this.maskedTextBox11.Location = new System.Drawing.Point(101, 161);
            this.maskedTextBox11.Mask = "00:00";
            this.maskedTextBox11.Name = "maskedTextBox11";
            this.maskedTextBox11.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox11.TabIndex = 38;
            this.maskedTextBox11.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox12
            // 
            this.maskedTextBox12.Location = new System.Drawing.Point(101, 136);
            this.maskedTextBox12.Mask = "90:00";
            this.maskedTextBox12.Name = "maskedTextBox12";
            this.maskedTextBox12.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox12.TabIndex = 37;
            this.maskedTextBox12.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox13
            // 
            this.maskedTextBox13.Location = new System.Drawing.Point(101, 110);
            this.maskedTextBox13.Mask = "00:00";
            this.maskedTextBox13.Name = "maskedTextBox13";
            this.maskedTextBox13.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBox13.TabIndex = 36;
            this.maskedTextBox13.ValidatingType = typeof(System.DateTime);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 264);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(54, 13);
            this.label30.TabIndex = 25;
            this.label30.Text = "Time Left:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 189);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(58, 13);
            this.label26.TabIndex = 23;
            this.label26.Text = "Time End?";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 164);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "Time Start?";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 138);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 13);
            this.label28.TabIndex = 21;
            this.label28.Text = "Date End?";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 113);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 13);
            this.label29.TabIndex = 20;
            this.label29.Text = "Date Start?";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 86);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(69, 13);
            this.label31.TabIndex = 18;
            this.label31.Text = "Book Name?";
            // 
            // MapsTab
            // 
            this.MapsTab.Controls.Add(this.panel1);
            this.MapsTab.Controls.Add(this.tabControl1);
            this.MapsTab.Location = new System.Drawing.Point(4, 22);
            this.MapsTab.Name = "MapsTab";
            this.MapsTab.Size = new System.Drawing.Size(1278, 694);
            this.MapsTab.TabIndex = 2;
            this.MapsTab.Text = "Library Maps";
            this.MapsTab.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Zoombar);
            this.panel1.Controls.Add(this.dataGridView3);
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.XBox);
            this.panel1.Controls.Add(this.YBox);
            this.panel1.Controls.Add(this.XBox2);
            this.panel1.Controls.Add(this.YBox2);
            this.panel1.Controls.Add(this.XBox3);
            this.panel1.Controls.Add(this.YBox3);
            this.panel1.Controls.Add(this.gmappointbox);
            this.panel1.Location = new System.Drawing.Point(821, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(424, 37);
            this.panel1.TabIndex = 14;
            // 
            // Zoombar
            // 
            this.Zoombar.Location = new System.Drawing.Point(3, 3);
            this.Zoombar.Maximum = 200;
            this.Zoombar.Minimum = 1;
            this.Zoombar.Name = "Zoombar";
            this.Zoombar.Size = new System.Drawing.Size(417, 45);
            this.Zoombar.TabIndex = 2;
            this.Zoombar.Value = 1;
            this.Zoombar.Scroll += new System.EventHandler(this.Zoombar_Scroll);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.ColumnHeadersVisible = false;
            this.dataGridView3.Location = new System.Drawing.Point(80, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(264, 31);
            this.dataGridView3.TabIndex = 17;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.ColumnHeadersVisible = false;
            this.dataGridView2.Location = new System.Drawing.Point(36, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(264, 31);
            this.dataGridView2.TabIndex = 16;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ColumnHeadersVisible = false;
            this.dataGridView1.Location = new System.Drawing.Point(3, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(264, 31);
            this.dataGridView1.TabIndex = 15;
            // 
            // XBox
            // 
            this.XBox.Location = new System.Drawing.Point(186, 4);
            this.XBox.Name = "XBox";
            this.XBox.Size = new System.Drawing.Size(34, 20);
            this.XBox.TabIndex = 9;
            // 
            // YBox
            // 
            this.YBox.Location = new System.Drawing.Point(226, 3);
            this.YBox.Name = "YBox";
            this.YBox.Size = new System.Drawing.Size(34, 20);
            this.YBox.TabIndex = 8;
            // 
            // XBox2
            // 
            this.XBox2.Location = new System.Drawing.Point(266, 3);
            this.XBox2.Name = "XBox2";
            this.XBox2.Size = new System.Drawing.Size(34, 20);
            this.XBox2.TabIndex = 7;
            // 
            // YBox2
            // 
            this.YBox2.Location = new System.Drawing.Point(306, 3);
            this.YBox2.Name = "YBox2";
            this.YBox2.Size = new System.Drawing.Size(34, 20);
            this.YBox2.TabIndex = 6;
            // 
            // XBox3
            // 
            this.XBox3.Location = new System.Drawing.Point(346, 3);
            this.XBox3.Name = "XBox3";
            this.XBox3.Size = new System.Drawing.Size(34, 20);
            this.XBox3.TabIndex = 5;
            // 
            // YBox3
            // 
            this.YBox3.Location = new System.Drawing.Point(386, 4);
            this.YBox3.Name = "YBox3";
            this.YBox3.Size = new System.Drawing.Size(34, 20);
            this.YBox3.TabIndex = 4;
            // 
            // gmappointbox
            // 
            this.gmappointbox.Location = new System.Drawing.Point(0, 0);
            this.gmappointbox.Name = "gmappointbox";
            this.gmappointbox.Size = new System.Drawing.Size(100, 50);
            this.gmappointbox.TabIndex = 3;
            this.gmappointbox.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.GroundFloorTab);
            this.tabControl1.Controls.Add(this.FirstFloorTab);
            this.tabControl1.Controls.Add(this.SecondFloorTab);
            this.tabControl1.Location = new System.Drawing.Point(4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1271, 687);
            this.tabControl1.TabIndex = 0;
            // 
            // GroundFloorTab
            // 
            this.GroundFloorTab.Controls.Add(this.GroundFloorpanel);
            this.GroundFloorTab.Location = new System.Drawing.Point(4, 22);
            this.GroundFloorTab.Name = "GroundFloorTab";
            this.GroundFloorTab.Padding = new System.Windows.Forms.Padding(3);
            this.GroundFloorTab.Size = new System.Drawing.Size(1263, 661);
            this.GroundFloorTab.TabIndex = 0;
            this.GroundFloorTab.Text = "Ground Floor";
            this.GroundFloorTab.UseVisualStyleBackColor = true;
            // 
            // GroundFloorpanel
            // 
            this.GroundFloorpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GroundFloorpanel.Controls.Add(this.gmapbox);
            this.GroundFloorpanel.Location = new System.Drawing.Point(0, 0);
            this.GroundFloorpanel.Name = "GroundFloorpanel";
            this.GroundFloorpanel.Size = new System.Drawing.Size(1263, 658);
            this.GroundFloorpanel.TabIndex = 0;
            this.GroundFloorpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.GroundFloorpanel_Paint);
            // 
            // gmapbox
            // 
            this.gmapbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gmapbox.ImageLocation = "0,50";
            this.gmapbox.Location = new System.Drawing.Point(-2, -2);
            this.gmapbox.Name = "gmapbox";
            this.gmapbox.Size = new System.Drawing.Size(1264, 655);
            this.gmapbox.TabIndex = 6;
            this.gmapbox.TabStop = false;
            // 
            // FirstFloorTab
            // 
            this.FirstFloorTab.Controls.Add(this.FirstFloorpanel);
            this.FirstFloorTab.Location = new System.Drawing.Point(4, 22);
            this.FirstFloorTab.Name = "FirstFloorTab";
            this.FirstFloorTab.Padding = new System.Windows.Forms.Padding(3);
            this.FirstFloorTab.Size = new System.Drawing.Size(1263, 661);
            this.FirstFloorTab.TabIndex = 1;
            this.FirstFloorTab.Text = "First Floor";
            this.FirstFloorTab.UseVisualStyleBackColor = true;
            // 
            // FirstFloorpanel
            // 
            this.FirstFloorpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.FirstFloorpanel.Controls.Add(this.mappointbox2);
            this.FirstFloorpanel.Controls.Add(this.mapbox2);
            this.FirstFloorpanel.Location = new System.Drawing.Point(0, 1);
            this.FirstFloorpanel.Name = "FirstFloorpanel";
            this.FirstFloorpanel.Size = new System.Drawing.Size(1263, 658);
            this.FirstFloorpanel.TabIndex = 1;
            this.FirstFloorpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.FirstFloorpanel_Paint);
            // 
            // mappointbox2
            // 
            this.mappointbox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mappointbox2.ImageLocation = "0,50";
            this.mappointbox2.Location = new System.Drawing.Point(-3, 0);
            this.mappointbox2.Name = "mappointbox2";
            this.mappointbox2.Size = new System.Drawing.Size(1264, 655);
            this.mappointbox2.TabIndex = 13;
            this.mappointbox2.TabStop = false;
            // 
            // mapbox2
            // 
            this.mapbox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mapbox2.ImageLocation = "0,50";
            this.mapbox2.Location = new System.Drawing.Point(-2, -2);
            this.mapbox2.Name = "mapbox2";
            this.mapbox2.Size = new System.Drawing.Size(1264, 655);
            this.mapbox2.TabIndex = 6;
            this.mapbox2.TabStop = false;
            // 
            // SecondFloorTab
            // 
            this.SecondFloorTab.Controls.Add(this.SecondFloorpanel);
            this.SecondFloorTab.Location = new System.Drawing.Point(4, 22);
            this.SecondFloorTab.Name = "SecondFloorTab";
            this.SecondFloorTab.Size = new System.Drawing.Size(1263, 661);
            this.SecondFloorTab.TabIndex = 2;
            this.SecondFloorTab.Text = "Second Floor";
            this.SecondFloorTab.UseVisualStyleBackColor = true;
            // 
            // SecondFloorpanel
            // 
            this.SecondFloorpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SecondFloorpanel.Controls.Add(this.mappointbox3);
            this.SecondFloorpanel.Controls.Add(this.mapbox3);
            this.SecondFloorpanel.Location = new System.Drawing.Point(0, 1);
            this.SecondFloorpanel.Name = "SecondFloorpanel";
            this.SecondFloorpanel.Size = new System.Drawing.Size(1263, 658);
            this.SecondFloorpanel.TabIndex = 2;
            this.SecondFloorpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.SecondFloorpanel_Paint);
            // 
            // mappointbox3
            // 
            this.mappointbox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mappointbox3.ImageLocation = "0,50";
            this.mappointbox3.Location = new System.Drawing.Point(-2, 1);
            this.mappointbox3.Name = "mappointbox3";
            this.mappointbox3.Size = new System.Drawing.Size(1264, 655);
            this.mappointbox3.TabIndex = 13;
            this.mappointbox3.TabStop = false;
            // 
            // mapbox3
            // 
            this.mapbox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mapbox3.ImageLocation = "0,50";
            this.mapbox3.Location = new System.Drawing.Point(-3, 0);
            this.mapbox3.Name = "mapbox3";
            this.mapbox3.Size = new System.Drawing.Size(1264, 655);
            this.mapbox3.TabIndex = 6;
            this.mapbox3.TabStop = false;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(0, 0);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 20);
            this.textBox27.TabIndex = 0;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(0, 0);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 20);
            this.textBox28.TabIndex = 0;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(0, 0);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 20);
            this.textBox29.TabIndex = 0;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(0, 0);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 20);
            this.textBox30.TabIndex = 0;
            // 
            // seatingDataSet1
            // 
            this.seatingDataSet1.DataSetName = "SeatingDataSet";
            this.seatingDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seatingDataSet1BindingSource
            // 
            this.seatingDataSet1BindingSource.DataSource = this.seatingDataSet1;
            this.seatingDataSet1BindingSource.Position = 0;
            // 
            // LibrarySystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 733);
            this.Controls.Add(this.SeatingTab);
            this.Name = "LibrarySystem";
            this.Text = "Library System";
            this.SeatingTab.ResumeLayout(false);
            this.SeatBookingTab.ResumeLayout(false);
            this.seattab.ResumeLayout(false);
            this.bookseat.ResumeLayout(false);
            this.bookseat.PerformLayout();
            this.seatgroup.ResumeLayout(false);
            this.seatgroup.PerformLayout();
            this.timeinfo.ResumeLayout(false);
            this.timeinfo.PerformLayout();
            this.BookBookingTab.ResumeLayout(false);
            this.BookBookingTab.PerformLayout();
            this.MapsTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Zoombar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gmappointbox)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.GroundFloorTab.ResumeLayout(false);
            this.GroundFloorpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gmapbox)).EndInit();
            this.FirstFloorTab.ResumeLayout(false);
            this.FirstFloorpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mappointbox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mapbox2)).EndInit();
            this.SecondFloorTab.ResumeLayout(false);
            this.SecondFloorpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mappointbox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mapbox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatingDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatingDataSet1BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl SeatingTab;
        private System.Windows.Forms.TabPage SeatBookingTab;
        private System.Windows.Forms.TabPage BookBookingTab;
        private System.Windows.Forms.TabPage MapsTab;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage GroundFloorTab;
        private System.Windows.Forms.TabPage FirstFloorTab;
        private System.Windows.Forms.TabPage SecondFloorTab;
        private System.Windows.Forms.Panel GroundFloorpanel;
        private System.Windows.Forms.TabControl seattab;
        private System.Windows.Forms.TabPage bookseat;
        private System.Windows.Forms.TabPage seatgroup;
        private System.Windows.Forms.TabPage timeinfo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.DateTimePicker DateBox;
        private System.Windows.Forms.ComboBox FloorBox;
        private System.Windows.Forms.ComboBox SeatTypeBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MaskedTextBox LengthBox;
        private System.Windows.Forms.MaskedTextBox StartTimeBox;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        private System.Windows.Forms.MaskedTextBox maskedTextBox10;
        private System.Windows.Forms.MaskedTextBox maskedTextBox11;
        private System.Windows.Forms.MaskedTextBox maskedTextBox12;
        private System.Windows.Forms.MaskedTextBox maskedTextBox13;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button bookbutton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox gmapbox;
        private System.Windows.Forms.TrackBar Zoombar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel FirstFloorpanel;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.PictureBox mapbox2;
        private System.Windows.Forms.Panel SecondFloorpanel;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.PictureBox mapbox3;
        private System.Windows.Forms.PictureBox mappointbox2;
        private System.Windows.Forms.PictureBox mappointbox3;
        private SeatingDataSet seatingDataSet1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource seatingDataSet1BindingSource;
        private System.Windows.Forms.PictureBox gmappointbox;
        private System.Windows.Forms.TextBox XBox;
        private System.Windows.Forms.TextBox YBox;
        private System.Windows.Forms.TextBox XBox2;
        private System.Windows.Forms.TextBox YBox2;
        private System.Windows.Forms.TextBox XBox3;
        private System.Windows.Forms.TextBox YBox3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label52;
    }
}

