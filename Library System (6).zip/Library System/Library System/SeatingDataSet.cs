﻿namespace Library_System
{


    partial class SeatingDataSet
    {
        partial class groundfloorDataTable
        {
        }
    }
}
